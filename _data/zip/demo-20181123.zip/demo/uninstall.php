/**
 * 卸载文件_demo99999
 * @作者 phpok
 * @版权 深圳市锟铻科技有限公司
 * @主页 http://www.phpok.com
 * @版本 5.x
 * @许可 http://www.phpok.com/lgpl.html PHPOK开源授权协议：GNU Lesser General Public License
 * @时间 2018年11月23日 21时45分
**/
/**
 * 安全限制，防止直接访问
**/
if(!defined("PHPOK_SET")){
	exit("<h1>Access Denied</h1>");
}
//$sql = "DROP TABLE IF EXISTS ".$this->db->prefix."demo";
//$this->db->query($sql);
//$sql = "SELECT * FROM ".$this->db->prefix."sysmenu WHERE appfile="demo"
//$rs = $this->db->get_one($sql);
//if($rs){
//	$sql = "DELETE FROM ".$this->db->prefix."popedom WHERE gid='".$rs['id']."'";
//	$this->db->query($sql);
//	$sql = "DELETE FROM ".$this->db->prefix."sysmenu WHERE id='".$rs['id']."'";
//	$this->db->query($sql);
//}

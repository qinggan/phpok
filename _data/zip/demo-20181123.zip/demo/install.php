/**
 * 安装文件_demo99999
 * @作者 phpok
 * @版权 深圳市锟铻科技有限公司
 * @主页 http://www.phpok.com
 * @版本 5.x
 * @许可 http://www.phpok.com/lgpl.html PHPOK开源授权协议：GNU Lesser General Public License
 * @时间 2018年11月23日 21时45分
**/
/**
 * 安全限制，防止直接访问
**/
if(!defined("PHPOK_SET")){
	exit("<h1>Access Denied</h1>");
}
//$sql = "";
//$this->db->query($sql);
//增加导航菜单
//$menu = array('parent_id'=>5,'title'=>测试用的,'status'=>1);
//$menu['appfile'] = 'demo';
//$menu['taxis'] = 255;
//$menu['site_id'] = 0;
//$menu['icon'] = 'newtab';
//$insert_id = $this->model('sysmenu')->save($menu);
//if($insert_id){
//	$tmparray = array('gid'=>$insert_id,'title'=>'查看','identifier'=>'list','taxis'=>10);
//	$this->model('popedom')->save($tmparray);
//	$tmparray = array('gid'=>$insert_id,'title'=>'删除','identifier'=>'delete','taxis'=>10);
//	$this->model('popedom')->save($tmparray);
//}

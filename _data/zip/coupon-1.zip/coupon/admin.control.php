<?php
/**
 * 后台管理_适用于整个PHPOK5平台的优惠系统
 * @作者 phpok.com <admin@phpok.com>
 * @版权 深圳市锟铻科技有限公司
 * @主页 http://www.phpok.com
 * @版本 5.x
 * @许可 http://www.phpok.com/lgpl.html PHPOK开源授权协议：GNU Lesser General Public License
 * @时间 2019年01月02日 15时35分
**/
namespace phpok\app\control\coupon;
/**
 * 安全限制，防止直接访问
**/
if(!defined("PHPOK_SET")){
	exit("<h1>Access Denied</h1>");
}
class admin_control extends \phpok_control
{
	private $popedom;
	public function __construct()
	{
		parent::control();
		$this->popedom = appfile_popedom('coupon');
		$this->assign("popedom",$this->popedom);
	}

	public function index_f()
	{
		if(!$this->popedom['list']){
			$this->error(P_Lang('您没有权限查看优惠码'));
		}
		$this->display('admin_index');
	}

	public function set_f()
	{
		$id = $this->get('id','int');
		if(!$id){
			if(!$this->popedom['add']){
				$this->error(P_Lang('您没有权限添加优惠码'));
			}
		}else{
			if(!$this->popedom['modify']){
				$this->error(P_Lang('您没有权限编辑优惠码'));
			}
			$rs = $this->model('coupon')->get_one($id);
			if(!$rs){
				$this->error(P_Lang('优惠码信息不存在'));
			}
			if($rs['startdate']){
				$rs['startdate'] = date("Y-m-d H:i:s",$rs['startdate']);
			}
			if($rs['stopdate']){
				$rs['stopdate'] = date("Y-m-d H:i:s",$rs['stopdate']);
			}
			$this->assign('rs',$rs);
			$this->assign('id',$id);
		}
		$condition = "module>0 AND is_biz>0 AND status=1";
		$plist = $this->model('project')->project_all($this->session->val('admin_site_id'),'id',$condition);
		if(!$plist){
			$this->error(P_Lang('系统没有找到带电商的项目，请先开启电商功能'));
		}
		$this->assign('plist',$plist);
		$this->display('admin_coupon_set');
	}
}

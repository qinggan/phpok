-- 卸载优惠码功能

DROP TABLE IF EXISTS qinggan_coupon;

DROP TABLE IF EXISTS qinggan_coupon_history;
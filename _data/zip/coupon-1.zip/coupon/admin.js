/**
 * 后面页面脚本_适用于整个PHPOK5平台的优惠系统
 * @作者 phpok.com <admin@phpok.com>
 * @版权 深圳市锟铻科技有限公司
 * @主页 http://www.phpok.com
 * @版本 5.x
 * @许可 http://www.phpok.com/lgpl.html PHPOK开源授权协议：GNU Lesser General Public License
 * @时间 2019年01月02日 15时35分
**/
;(function($){
	$.admin_coupon = {
		del:function(id,code)
		{
			var tip = p_lang('确定要删除优惠码{code}吗？未过期的优惠码不建议删除',' <span class="red">'+code+'</span>');
			$.dialog.confirm(tip,function(){
				var url = get_url('coupon','delete','id='+id);
				$.phpok.json(url,function(rs){
					if(rs.status){
						$.dialog.tips(p_lang('删除成功'),function(){
							$.phpok.reload();
						}).lock();
						return true;
					}
					$.dialog.alert(rs.info);
					return false;
				});
			});
		},
		rand:function()
		{
			var str = $.phpok.rand('letter',1)+$.phpok.rand('fixed',8);
			$("#code").val(str.toUpperCase());
			return true;
		}
	}
})(jQuery);

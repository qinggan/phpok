<?php
/**
 * 模型内容信息_检测PHPOK系统是否安全
 * @作者 phpok.com <admin@phpok.com>
 * @版权 深圳市锟铻科技有限公司
 * @主页 http://www.phpok.com
 * @版本 5.x
 * @许可 http://www.phpok.com/lgpl.html PHPOK开源授权协议：GNU Lesser General Public License
 * @时间 2018年12月08日 10时01分
**/
namespace phpok\app\model\safecheck;
/**
 * 安全限制，防止直接访问
**/
if(!defined("PHPOK_SET")){
	exit("<h1>Access Denied</h1>");
}
class model extends \phpok_model
{
	public function __construct()
	{
		parent::model();
	}

	public function save($data)
	{
		return $this->lib('xml')->save($data,$this->dir_data.'safecheck.config.php');
	}

	public function get_one()
	{
		if(is_file($this->dir_data.'safecheck.config.php')){
			return $this->lib('xml')->read($this->dir_data.'safecheck.config.php');
		}
		return false;
	}

	public function ip()
	{
		$info = $this->get_one();
		if(!$info){
			return false;
		}
		return $info['ip'];
	}
}

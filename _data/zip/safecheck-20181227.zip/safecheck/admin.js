/**
 * 后面页面脚本_检测PHPOK系统是否安全
 * @作者 phpok.com <admin@phpok.com>
 * @版权 深圳市锟铻科技有限公司
 * @主页 http://www.phpok.com
 * @版本 5.x
 * @许可 http://www.phpok.com/lgpl.html PHPOK开源授权协议：GNU Lesser General Public License
 * @时间 2018年12月08日 10时01分
**/
;(function($){
	$.admin_safecheck = {
		setting:function()
		{
			$.dialog.open(get_url('safecheck','setting'),{
				'title':p_lang('安全检测配置'),
				'lock':true,
				'width':'500px',
				'height':'267px',
				'ok':function(){
					var iframe = this.iframe.contentWindow;
					if (!iframe.document.body) {
						alert('iframe还没加载完毕呢');
						return false;
					};
					iframe.save();
					return false;
				},
				'okVal':p_lang('保存配置'),
				'cancel':true
			})
		},
		start:function()
		{
			var t = $("#safe-report").attr('data-check');
			if(t != 1){
				$.dialog.alert(p_lang('未配置好远程，不支持验证'));
				return false;
			}
			var self = this;
			var act = $.dialog.tips('开始比较，请耐心等待…',100).lock();
			var url = get_url('safecheck','start');
			$.phpok.json(url,function(rs){
				act.close();
				if(!rs.status){
					$.dialog.alert(rs.info);
					return false;
				}
				$("#safe-report").show();
				$("#safe-report").find('tbody').html('');
				var data = rs.info;
				if(data.check){
					var tmp = (data.check).join(',');
					$("#safe-report").attr('data-list',tmp).attr("data-index",'0')
				}
				if(data.folders){
					for(var i in data.folders){
						var html = self._tpl(data.folders[i]);
						$("#safe-report").find('tbody').append(html);
					}
				}
				if(data.files){
					for(var i in data.files){
						var html = self._tpl(data.files[i]);
						$("#safe-report").find('tbody').append(html);
					}
				}
				//self.check();
				return true;
			})
		},
		check:function()
		{
			var self = this;
			var info = $("#safe-report").attr('data-list');
			if(!info){
				$.dialog.alert()
			}
			var index = $("#safe-report").attr('data-index');
		},
		_tpl:function(info)
		{
			var html = '<tr>';
			html += '<td>'+info.name+'</td>';
			html += '<td>'+info.file+'</td>';
			html += '<td>'+info.status+'</td>';
			html += '<td>'+info.info+'</td>';
			html += '</tr>';
			return html;
		}
	}
})(jQuery);

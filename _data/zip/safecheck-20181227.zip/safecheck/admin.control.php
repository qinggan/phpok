<?php
/**
 * 后台管理_检测PHPOK系统是否安全
 * @作者 phpok.com <admin@phpok.com>
 * @版权 深圳市锟铻科技有限公司
 * @主页 http://www.phpok.com
 * @版本 5.x
 * @许可 http://www.phpok.com/lgpl.html PHPOK开源授权协议：GNU Lesser General Public License
 * @时间 2018年12月08日 10时01分
**/
namespace phpok\app\control\safecheck;
/**
 * 安全限制，防止直接访问
**/
if(!defined("PHPOK_SET")){
	exit("<h1>Access Denied</h1>");
}
class admin_control extends \phpok_control
{
	private $popedom;
	public function __construct()
	{
		parent::control();
		$this->popedom = appfile_popedom('safecheck');
		$this->assign("popedom",$this->popedom);
	}

	private function _folders()
	{
		$data = array('_root'=>P_Lang('根目录'));
		$data['_app'] = P_Lang('应用');
		$data['_cache'] = P_Lang('缓存');
		$data['_config'] = P_Lang('配置');
		$data['_data'] = P_Lang('数据');
		$data['css'] = P_Lang('后台样式');
		$data['extension'] = P_Lang('扩展类');
		$data['framework'] = P_Lang('核心');
		$data['gateway'] = P_Lang('网关');
		$data['images'] = P_Lang('图片');
		$data['install'] = P_Lang('安装');
		$data['js'] = P_Lang('JS库');
		$data['langs'] = P_Lang('语言包');
		$data['phpinc'] = P_Lang('模板执行PHP');
		$data['plugins'] = P_Lang('插件');
		$data['res'] = P_Lang('附件');
		$data['static'] = P_Lang('LayUI资源');
		$data['task'] = P_Lang('计划任务');
		$data['tpl'] = P_Lang('模板');
		$data['wxapp'] = P_Lang('微信小程序');
		return $data;
	}

	public function index_f()
	{
		$rs = $this->model('safecheck')->get_one();
		$check_action = true;
		if(!$rs){
			$check_action = false;
		}
		$this->assign('check_action',$check_action);
		$this->display('admin_index');
	}

	public function setting_f()
	{
		$rs = $this->model('safecheck')->get_one();
		if($rs){
			$this->assign('rs',$rs);
		}
		$this->display('admin_setting');
	}

	public function save_f()
	{
		$data = array();
		$data['server'] = $this->get('server');
		if(!$data['server']){
			$this->error(P_Lang('服务器不能为空'));
		}
		$data['https'] = $this->get('https','int');
		$data['ip'] = $this->get('ip');
		$this->model('safecheck')->save($data);
		$this->success();
	}

	public function start_f()
	{
		$this->config('is_ajax',true);
		$url = $this->_act_url();
		if(!$url){
			$this->error(P_Lang('未配置好远程，不支持验证'));
		}
		$localist = $this->lib('file')->ls($this->dir_root);
		if(!$localist){
			$this->error(P_Lang('获取本地目录失败'));
		}
		$local = array('folders'=>array(),'files'=>array());
		foreach($localist as $key=>$value){
			$tmpid = str_replace($this->dir_root,'',$value);
			if(substr($tmpid,-1) == '/'){
				$tmpid = substr($tmpid,0,-1);
			}
			$tmpid = 'ok_'.md5($tmpid);
			if(is_dir($value)){
				$local['folders'][$tmpid] = array('name'=>basename($value),'file'=>str_replace($this->dir_root,'',$value),'type'=>'folder');
			}else{
				$tmp = array();
				$tmp['md5'] = md5_file($value);
				$tmp['size'] = filesize($value);
				$tmp['name'] = basename($value);
				$tmp['file'] = str_replace($this->dir_root,'',$value);
				$tmp['filetime'] = filemtime($value);
				$local['files'][$tmpid] = $tmp;
			}
		}
		$ip = $this->model('safecheck')->ip();
		if($ip){
			$this->lib('curl')->host_ip($ip);
		}
		$list = $this->lib('curl')->get_json($url);
		if(!$list){
			$this->error(P_Lang('远程信息获取失败'));
		}
		if(!$list['status']){
			$this->error($list['info']);
		}
		$remote = array('folders'=>array(),'files'=>array());
		foreach($list['info'] as $key=>$value){
			$tmpid = 'ok_'.md5($value['file']);
			if($value['ext'] == 'folder'){
				$remote['folders'][$tmpid] = $value;
			}else{
				$remote['files'][$tmpid] = $value;
			}
		}
		$rs = $this->_compare($local,$remote);
		$this->success($rs);
	}

	private function _compare($local,$remote)
	{
		$folders = array();
		$files = array();
		$check = array();
		foreach($local['folders'] as $key=>$value){
			if($remote['folders'][$key]){
				$check[] = $value;
				continue;
			}
			$value['status'] = 0;
			$value['info'] = P_Lang('未知');
			$folders[] = $value;
		}
		foreach($local['files'] as $key=>$value){
			if(!$remote['files'][$key]){
				$value['status'] = 0;
				$value['info'] = P_Lang('文件无法与远程匹配');
				$files[] = $value;
				continue;
			}
			//如果MD5一致，则跳过
			if($remote['files'][$key]['md5'] == $value['md5']){
				continue;
			}
			if($value['size'] > ($remote['files'][$key]['size'] + 1024) || $value['size'] < ($remote['files'][$key]['size'] + 1024)){
				$value['status'] = -9;
				$value['info'] = '文件大小严重不匹配';
				$files[] = $value;
				continue;
			}
			if($value['filetime'] > ($remote['files'][$key]['filetime'] + 43200) || $value['filetime'] < ($remote['files'][$key]['filetime'] + 43200)){
				$value['status'] = -5;
				$value['info'] = '时间误差超过12小时';
				$files[] = $value;
				continue;
			}
			$value['status'] = -1;
			$value['info'] = '文件MD5不匹配';
			$files[] = $value;
		}
		return array('folders'=>$folders,'files'=>$files,'check'=>$check);
	}

	private function _act_url($act='')
	{
		$rs = $this->model('safecheck')->get_one();
		if(!$rs){
			return false;
		}
		$url = $rs['https'] ? 'https://' : 'http://';
		$url.= $rs['server'].'/index.php?id=_safecheck';
		if($act){
			$url .= "&type=".rawurlencode($act);
		}
		return $url;
	}
}

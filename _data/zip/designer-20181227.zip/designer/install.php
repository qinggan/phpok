<?php
/**
 * 安装文件_应用于网页风格可视化在线设计
 * @作者 phpok.com <admin@phpok.com>
 * @版权 深圳市锟铻科技有限公司
 * @主页 http://www.phpok.com
 * @版本 5.x
 * @许可 http://www.phpok.com/lgpl.html PHPOK开源授权协议：GNU Lesser General Public License
 * @时间 2018年12月11日 21时07分
**/
/**
 * 安全限制，防止直接访问
**/
if(!defined("PHPOK_SET")){
	exit("<h1>Access Denied</h1>");
}
$sql = "CREATE TABLE IF NOT EXISTS `".$this->db->prefix."designer` (`id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT '自增ID',`tpl_id` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '模板ID',`filename` varchar(255) NOT NULL COMMENT '文件名，不包含后缀',`title` varchar(255) NOT NULL COMMENT '名称，用于后台管理',`maxwidth` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '0表示不限宽度',`adaptive` int(1) NOT NULL DEFAULT '0' COMMENT '0普通网页1自适应',`is_mobile` int(1) NOT NULL DEFAULT '0' COMMENT '0存放在PC目录上，1存在手机版',`content` longtext NOT NULL COMMENT '模板设计器的内容',PRIMARY KEY (`id`)) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='网页设计器' AUTO_INCREMENT=1";
$this->db->query($sql);

//增加导航菜单
$menu = array('parent_id'=>5,'title'=>'模板设计器','status'=>1);
$menu['appfile'] = 'designer';
$menu['taxis'] = 255;
$menu['site_id'] = 0;
$menu['icon'] = 'newtab';
$insert_id = $this->model('sysmenu')->save($menu);
if($insert_id){
	$tmparray = array('gid'=>$insert_id,'title'=>'查看','identifier'=>'list','taxis'=>10);
	$this->model('popedom')->save($tmparray);
	$tmparray = array('gid'=>$insert_id,'title'=>'添加','identifier'=>'add','taxis'=>20);
	$this->model('popedom')->save($tmparray);
	$tmparray = array('gid'=>$insert_id,'title'=>'编辑','identifier'=>'modify','taxis'=>30);
	$this->model('popedom')->save($tmparray);
	$tmparray = array('gid'=>$insert_id,'title'=>'应用','identifier'=>'apply','taxis'=>40);
	$this->model('popedom')->save($tmparray);
	$tmparray = array('gid'=>$insert_id,'title'=>'设计','identifier'=>'design','taxis'=>50);
	$this->model('popedom')->save($tmparray);
	$tmparray = array('gid'=>$insert_id,'title'=>'删除','identifier'=>'delete','taxis'=>60);
	$this->model('popedom')->save($tmparray);
}

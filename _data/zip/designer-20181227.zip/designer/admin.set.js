/**
 * 设置页
 * @作者 qinggan <admin@phpok.com>
 * @版权 深圳市锟铻科技有限公司
 * @主页 http://www.phpok.com
 * @版本 5.x
 * @授权 http://www.phpok.com/lgpl.html 开源授权协议：GNU Lesser General Public License
 * @时间 2018年12月11日
**/
function save()
{
	var opener = $.dialog.opener;
	$("#post_save").ajaxSubmit({
		'url':get_url('designer','setok'),
		'type':'post',
		'dataType':'json',
		'success':function(rs){
			if(rs.status){
				var id = $("#id").val();
				var tip = id ? p_lang('文件信息编辑成功') : p_lang('文件信息创建成功');
				$.dialog.alert(tip,function(){
					opener.$.phpok.reload();
				},'succeed');
				return true;
			}
			$.dialog.alert(rs.info);
			return false;
		}
	});
	return false;
}
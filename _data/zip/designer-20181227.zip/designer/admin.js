/**
 * 后面页面脚本_应用于网页风格可视化在线设计
 * @作者 phpok.com <admin@phpok.com>
 * @版权 深圳市锟铻科技有限公司
 * @主页 http://www.phpok.com
 * @版本 5.x
 * @许可 http://www.phpok.com/lgpl.html PHPOK开源授权协议：GNU Lesser General Public License
 * @时间 2018年12月11日 21时07分
**/
;(function($){
	$.admin_designer = {
		add:function()
		{
			var url = get_url('designer','set');
			$.dialog.open(url,{
				'title':p_lang('添加页面'),
				'width':'500px',
				'height':'384px',
				'lock':true,
				'okVal':p_lang('提交保存'),
				'cancel':true,
				'ok':function(){
					var iframe = this.iframe.contentWindow;
					if (!iframe.document.body) {
						alert('iframe还没加载完毕呢');
						return false;
					};
					iframe.save();
					return false;
				}
			})
		},
		edit:function(id)
		{
			var url = get_url('designer','set','id='+id);
			$.dialog.open(url,{
				'title':p_lang('编辑页面')+"_#"+id,
				'width':'500px',
				'height':'384px',
				'lock':true,
				'okVal':p_lang('提交保存'),
				'cancel':true,
				'ok':function(){
					var iframe = this.iframe.contentWindow;
					if (!iframe.document.body) {
						alert('iframe还没加载完毕呢');
						return false;
					};
					iframe.save();
					return false;
				}
			})
		},
		del:function(id)
		{
			var tip = p_lang('确定要删除ID：{id} 的信息吗？','<span class="red">'+id+'</span>');
			$.dialog.confirm(tip,function(){
				var url = get_url('designer','delete','id='+id);
				$.phpok.json(url,function(rs){
					if(rs.status){
						$.dialog.tips(p_lang('删除成功'),function(){
							$.phpok.reload();
						}).lock();
						return true;
					}
					$.dialog.alert(rs.info);
					return false;
				});
			});
		},
		create:function(id,isfile)
		{
			if(isfile && isfile == 1){
				var tip = p_lang('确定要生成ID：{id} 的模板内容吗？<div class="red">注意：使用后会覆盖当前模板文件，请仔细检查</span>','<span class="red">'+id+'</span>');
			}else{
				var tip = p_lang('确定要生成ID：{id} 的模板内容吗？','<span class="red">'+id+'</span>');
			}
			$.dialog.confirm(tip,function(){
				var url = get_url('designer','apply','id='+id);
				$.phpok.json(url,function(rs){
					if(rs.status){
						$.dialog.tips(p_lang('模板文件应用成功'),function(){
							$.phpok.reload();
						}).lock();
						return true;
					}
					$.dialog.alert(rs.info);
					return false;
				})
			});
		},
		act:function(id)
		{
			var url = get_url('designer','act','id='+id);
			var title = p_lang('在线设计')+"_#"+id;
			$.win(title,url);
		}
	}
})(jQuery);

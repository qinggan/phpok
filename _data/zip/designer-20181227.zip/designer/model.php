<?php
/**
 * 模型内容信息_应用于网页风格可视化在线设计
 * @作者 phpok.com <admin@phpok.com>
 * @版权 深圳市锟铻科技有限公司
 * @主页 http://www.phpok.com
 * @版本 5.x
 * @许可 http://www.phpok.com/lgpl.html PHPOK开源授权协议：GNU Lesser General Public License
 * @时间 2018年12月11日 21时07分
**/
namespace phpok\app\model\designer;
/**
 * 安全限制，防止直接访问
**/
if(!defined("PHPOK_SET")){
	exit("<h1>Access Denied</h1>");
}
class model extends \phpok_model
{
	public function __construct()
	{
		parent::model();
	}

	public function get_one($id)
	{
		$sql = "SELECT * FROM ".$this->db->prefix."designer WHERE id='".$id."'";
		return $this->db->get_one($sql);
	}

	public function save($data,$id=0)
	{
		if(!$data || !is_array($data)){
			return false;
		}
		if($id){
			return $this->db->update_array($data,"designer",array("id"=>$id));
		}else{
			return $this->db->insert_array($data,"designer");
		}
	}

	public function get_all($condition='',$offset=0,$psize=30,$orderby='',$pri='')
	{
		$sql = "SELECT id,tpl_id,filename,title,maxwidth,adaptive,is_mobile FROM ".$this->db->prefix."designer ";
		if($condition){
			$sql .= " WHERE ".$condition." ";
		}
		if($orderby){
			$sql .= " ORDER BY ".$orderby." ";
		}
		if($psize && intval($psize)>0){
			$sql .= " LIMIT ".intval($offset).",".$psize;
		}
		return $this->db->get_all($sql,$pri);
	}

	public function get_total($condition)
	{
		$sql = "SELECT count(id) FROM ".$this->db->prefix."designer ";
		if($condition){
			$sql .= " WHERE ".$condition." ";
		}
		return $this->db->count($sql);
	}

	public function filename_check($filename,$tpl_id,$is_mobile=0,$id=0)
	{
		$sql = "SELECT id FROM ".$this->db->prefix."designer WHERE filename='".$filename."'";
		$sql.= " AND tpl_id='".$tpl_id."'";
		$sql.= " AND is_mobile='".$is_mobile."'";
		if($id){
			$sql.= " AND id !='".$id."'";
		}
		return $this->db->get_one($sql);
	}

	public function del($id)
	{
		$sql = "DELETE FROM ".$this->db->prefix."designer WHERE id='".$id."'";
		return $this->db->query($sql);
	}

	//布局映射成HTML
	public function layout2tpl($content)
	{
		return $content;
	}
}

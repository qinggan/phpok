<?php
/**
 * 后台管理_应用于网页风格可视化在线设计
 * @作者 phpok.com <admin@phpok.com>
 * @版权 深圳市锟铻科技有限公司
 * @主页 http://www.phpok.com
 * @版本 5.x
 * @许可 http://www.phpok.com/lgpl.html PHPOK开源授权协议：GNU Lesser General Public License
 * @时间 2018年12月11日 21时07分
**/
namespace phpok\app\control\designer;
/**
 * 安全限制，防止直接访问
**/
if(!defined("PHPOK_SET")){
	exit("<h1>Access Denied</h1>");
}
class admin_control extends \phpok_control
{
	private $popedom;
	public function __construct()
	{
		parent::control();
		$this->popedom = appfile_popedom('designer');
		$this->assign("popedom",$this->popedom);
	}

	public function index_f()
	{
		if(!$this->popedom['list']){
			$this->error(P_Lang('您没有查看权限'));
		}
		$tmplist = $this->model('tpl')->get_all();
		if(!$tmplist){
			$this->error(P_Lang('没有找到风格，请先创建'));
		}
		$tplist = array();
		foreach($tmplist as $key=>$value){
			if(!$value['ext']){
				$value['ext'] = 'html';
			}
			$tplist[$value['id']] = $value;
		}
		$pageid = $this->get($this->config['pageid'],'int');
		if(!$pageid){
			$pageid = 1;
		}
		$psize = $this->config['psize'] ? $this->config['psize'] : 30;
		$offset = ($pageid-1) * $psize;
		$condition = "";
		$keywords = $this->get('keywords');
		$pageurl = $this->url('designer');
		if($keywords){
			$condition = "1=1 ";
			if($keywords['title']){
				$condition .= " AND title LIKE '%".$keywords['title']."%' ";
				$pageurl .= "&keywords[title]=".rawurlencode($keywords['title']);
			}
			if($keywords['filename']){
				$condition .= " AND filename LIKE '%".$keywords['filename']."%' ";
				$pageurl .= "&keywords[filename]=".rawurlencode($keywords['filename']);
			}
			if($keywords['tpl_id']){
				$condition .= " AND tpl_id='".$keywords['tpl_id']."' ";
				$pageurl .= "&keywords[tpl_id]=".rawurlencode($keywords['tpl_id']);
			}
			if($keywords['is_mobile']){
				$condition .= " AND is_mobile='".($keywords['is_mobile'] == 1 ? 1 : 0)."' ";
				$pageurl .= "&keywords[is_mobile]=".rawurlencode($keywords['is_mobile']);
			}
			if($keywords['adaptive']){
				$condition .= " AND adaptive='".($keywords['adaptive'] == 1 ? 1 : 0)."' ";
				$pageurl .= "&keywords[adaptive]=".rawurlencode($keywords['adaptive']);
			}
		}
		$total = $this->model('designer')->get_total($condition);
		if($total){
			$rslist = $this->model('designer')->get_all($condition,$offset,$psize);
			if($rslist){
				foreach($rslist as $key=>$value){
					$tmp = $tplist[$value['tpl_id']] ? $tplist[$value['tpl_id']] : false;
					$value['has_file'] = false;
					if($tmp){
						$tmpfile = $this->dir_root.'tpl/'.$tmp['folder'].'/'.$value['filename'].'.'.$tmp['ext'];
						$value['has_file'] = is_file($tmpfile) ? true : false;
					}
					$rslist[$key] = $value;
				}
			}
			$this->assign('rslist',$rslist);
			$this->assign('total',$total);
			$this->assign('pageid',$pageid);
			$this->assign('psize',$psize);
			$this->assign('offset',$offset);
			$this->assign('pageurl',$pageurl);
			$string = P_Lang("home=首页&prev=上一页&next=下一页&last=尾页&half=5&add=数量：(total)/(psize)，页码：(num)/(total_page)&always=1");
			$pagelist = phpok_page($pageurl,$total,$pageid,$psize,$string);
			$this->assign("pagelist",$pagelist);
		}
		$this->display('admin_index');
	}

	public function set_f()
	{
		$id = $this->get('id','int');
		if($id){
			if(!$this->popedom['modify']){
				$this->error(P_Lang('您没有编辑权限'));
			}
		}else{
			if(!$this->popedom['add']){
				$this->error(P_Lang('您没有添加权限'));
			}
		}
		$tplist = $this->model('tpl')->get_all();
		if(!$tplist){
			$this->error(P_Lang('没有找到风格，请先创建'));
		}
		$this->assign('tplist',$tplist);
		if($id){
			$rs = $this->model('designer')->get_one($id);
			$this->assign('rs',$rs);
			$this->assign('id',$id);
		}
		$this->display('admin_set');
	}

	public function setok_f()
	{
		$id = $this->get('id','int');
		if($id){
			if(!$this->popedom['modify']){
				$this->error(P_Lang('您没有编辑权限'));
			}
		}else{
			if(!$this->popedom['add']){
				$this->error(P_Lang('您没有添加权限'));
			}
		}
		$data = array();
		$data['title'] = $this->get('title');
		if(!$data['title']){
			$this->error(P_Lang('名称不能为空'));
		}
		$data['tpl_id'] = $this->get('tpl_id','int');
		if(!$data['tpl_id']){
			$this->error(P_Lang('风格项必须选'));
		}
		$data['filename'] = $this->get('filename','system');
		if(!$data['filename']){
			$this->error(P_Lang('文件名不能为空'));
		}
		$data['maxwidth'] = $this->get('maxwidth','int');
		$data['adaptive'] = $this->get('adaptive','int');
		$data['is_mobile'] = $this->get('is_mobile','int');
		$chk = $this->model('designer')->filename_check($data['filename'],$data['tpl_id'],$data['is_mobile'],$id);
		if($chk){
			$this->error(P_Lang('文件名已经存在，请更改'));
		}
		$this->model('designer')->save($data,$id);
		$this->success();
	}

	public function delete_f()
	{
		if(!$this->popedom['delete']){
			$this->error(P_Lang('您没有删除权限'));
		}
		$id = $this->get('id','int');
		if(!$id){
			$this->error(P_Lang('未指定ID'));
		}
		$this->model('designer')->del($id);
		$this->success();
	}

	public function apply_f()
	{
		if(!$this->popedom['apply']){
			$this->error(P_Lang('您没有应用模板权限'));
		}
		$id = $this->get('id','int');
		if(!$id){
			$this->error(P_Lang('未指定ID'));
		}
		$rs = $this->model('designer')->get_one($id);
		if(!$rs){
			$this->error(P_Lang('模板信息不存在'));
		}
		if(!$rs['content']){
			$this->error(P_Lang('没有内容'));
		}
		$tpl_rs = $this->model('tpl')->get_one($rs['tpl_id']);
		if(!$tpl_rs){
			$this->error(P_Lang('风格不存在，请检查'));
		}
		$dir = $this->dir_root.'tpl/'.$tpl_rs['folder'];
		if($rs['is_mobile']){
			$dir.= "_mobile";
		}
		if(!file_exists($dir)){
			$this->lib('file')->make($dir,'folder');
		}
		if(!file_exists($dir)){
			$this->error(P_Lang('风格目录不存在，请检查'));
		}
		$content = $this->model('designer')->layout2tpl($rs['content']);
		if(!$tpl_rs['ext']){
			$tpl_rs['ext'] = 'html';
		}
		$this->lib('file')->vim($content,$dir.'/'.$rs['filename'].'.'.$tpl_rs['ext']);
		$this->success();
	}

	public function act_f()
	{
		$id = $this->get('id','int');
		if(!$id){
			$this->error(P_Lang('未指定ID'));
		}
		$rs = $this->model('designer')->get_one($id);
		if(!$rs){
			$this->error(P_Lang('不存在'));
		}
		$this->assign('rs',$rs);
		$this->display('admin_designer');
	}
}
